## Change Log
**v9 - 2023.12.6 (202312060)**
- Added Magisk Manager + MRepo update support
- Updated documentation

**v8 - 2023.11.4 (202311040)**
- Updated Magisk version support to **Magisk v19.0 - v26.X**
- Updated documentation

**v7 - 2022.6.26 (202206260)**
- Updated Magisk version support to **Magisk v19.0 - v25.X**
- Updated documentation

**v6 - 2021.6.6 (202106060)**
- Updated Magisk version support to **Magisk v19.0 - v23.X**
- Updated documentation

**v5 - 2020.4.17 (202004170)**
- Updated Magisk version support to **Magisk v19.0 - v20.X**
- Updated documentation

**v4 - 2019.4.4 (201904040)**
- Updated Magisk version support to **Magisk v17.0 - v19.X** (including `uninstall.sh`)
- Updated documentation
- Toggle core only mode
- Complete redesign

**v3 - 2018.8.1 (201808010)**
- Updated documentation
- General optimizations
- New & simplified installer
- Striped down (removed unnecessary code & files)

**v2 - 2018.7.24 (201807240)**
- Updated documentation
- Fixed modPath detection issue on **Magisk v16.6**

bash build.sh
pause
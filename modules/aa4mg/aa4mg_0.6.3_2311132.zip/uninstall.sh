#!/bin/bash

pm uninstall-system-updates com.google.android.projection.gearhead
